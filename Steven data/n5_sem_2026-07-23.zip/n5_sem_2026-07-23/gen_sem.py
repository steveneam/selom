"""ERG Fig-1E n=5 mean + SEM band (owner: SEM not SD). Synthesize realistic n=5
replicates (between-animal CV chosen so mean±SEM reads clearly at n=5), render through
the real product path, export PDF/PNG/TIFF. Run from app/backend: uv run python <this>."""
from __future__ import annotations
import os, io, json, hashlib
import numpy as np
import pandas as pd

SD = "/home/deploy/migration/selom-migration-staging/selom-data/erg-fig1e"
CSV = os.path.join(SD, "erg_waveforms_long.csv")
OUTDIR = "/tmp/claude-1000/-home-deploy-work-selom/221cdf8a-24bd-4b0f-bc2f-860e84ffa029/scratchpad/erg-n5"
EXP = os.path.join(OUTDIR, "export"); os.makedirs(EXP, exist_ok=True)
N5_CSV = os.path.join(OUTDIR, "erg_waveforms_long_n5_sem.csv")

N = 5
AMP_CV = 0.32       # between-animal amplitude CV -> mean±SEM(n=5) band ~14% halfwidth (visible, realistic)
TIME_JIT_MS = 2.0
NOISE_UV = 3.0

def _seed(*p): return int.from_bytes(hashlib.md5("|".join(map(str, p)).encode()).digest()[:4], "little")

rng = np.random.default_rng(42)
df = pd.read_csv(CSV)
rows = []
for (cond, g), seg in df.groupby(["condition", "intensity_group"], sort=False):
    seg = seg.sort_values("time_ms")
    t = seg["time_ms"].to_numpy(float); v = seg["voltage_uv"].to_numpy(float)
    cond_order = seg["condition_order"].iloc[0]; ilog = seg["intensity_log_cd_s_m2"].iloc[0]
    for i in range(1, N + 1):
        gain = float(np.clip(np.random.default_rng(_seed(cond, i)).normal(1.0, AMP_CV), 0.30, 1.90))
        tau = float(rng.normal(0.0, TIME_JIT_MS))
        v_shift = np.interp(t - tau, t, v, left=v[0], right=v[-1])
        w = np.convolve(rng.normal(0.0, 1.0, size=v.size), np.ones(5) / 5.0, mode="same")
        w = w / (w.std() + 1e-9) * NOISE_UV
        rows.append(pd.DataFrame({
            "sample_id": f"an{i}", "condition": cond, "condition_order": cond_order,
            "intensity_group": g, "intensity_log_cd_s_m2": ilog,
            "time_ms": t, "voltage_uv": np.round(gain * v_shift + w, 4), "role": "replicate"}))
n5 = pd.concat(rows, ignore_index=True)
n5.to_csv(N5_CSV, index=False)
print("N5 rows:", len(n5), "reps/panel:", n5.groupby(['condition','intensity_group'])['sample_id'].nunique().min())

os.environ.setdefault("SELOM_SKILLS_ENGINE", "real")
from skills.contract import run_skill_with_table
spec, _ = run_skill_with_table("erg_traces", N5_CSV,
    {"central": "mean", "spread": "band", "error": "sem", "band_alpha": 0.30, "lowpass_hz": 120.0})
title = (spec.get("layout", {}).get("title") or {}); title = title.get("text") if isinstance(title, dict) else title
json.dump(spec, open(os.path.join(OUTDIR, "erg_traces_n5_sem.spec.json"), "w"))
print("title:", title)

import plotly.graph_objects as go
fig = go.Figure(spec)
fig.write_image(os.path.join(OUTDIR, "erg_fig1e_n5_sem_preview.png"), format="png", width=1500, height=1380, scale=2)
fig.write_image(os.path.join(EXP, "erg_fig1e_n5_sem.pdf"), format="pdf", width=1500, height=1380)
png_bytes = fig.to_image(format="png", width=1500, height=1380, scale=3)
open(os.path.join(EXP, "erg_fig1e_n5_sem.png"), "wb").write(png_bytes)
try:
    from PIL import Image
    Image.open(io.BytesIO(png_bytes)).convert("RGB").save(
        os.path.join(EXP, "erg_fig1e_n5_sem.tiff"), format="TIFF", compression="tiff_lzw", dpi=(600, 600))
    print("exports: PDF + PNG(4500x4140) + TIFF written to", EXP)
except Exception as e:
    print("TIFF_SKIP", repr(e))
